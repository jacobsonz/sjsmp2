# ZJSMP GitHub build project

This project is a GitHub Actions/Maven build wrapper around the existing ZJSMP 1.0.0 plugin JAR.

## GitHub
Upload the CONTENTS of this folder to the root of the repository (not the ZIP itself), replacing the old workflow.

Expected layout:

- pom.xml
- input/ZJSMP-original.jar
- .github/workflows/main.yml

Then open Actions -> Build ZJSMP -> Run workflow.

The artifact will be named `ZJSMP-26.2-JAR` and contain `ZJSMP.jar`.

This does not decompile or recreate source code; it makes the existing ZJSMP binary reproducibly packageable by GitHub Actions.
